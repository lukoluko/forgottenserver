<div class="sidebar">
	<h2>Character search</h2>
	<div class="inner">
		<form type="submit" action="characterprofile.php" method="get">
			<input type="text" name="name" class="search">
		</form>
	</div>
</div>